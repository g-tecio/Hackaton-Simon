new Vue({
  el: '#app',
  data: {
    centerButton: "Start",
    playing: true,
    isClickable: false,
    isWon: false,
    isWrong: false,
    score: 0,
    sequence: [],
    sequenceInterval: null,
    playerSequence: [],
    sounds: [
    new Howl({
      src: ["https://s3-us-west-1.amazonaws.com/sayspring-prod/media/celtic-open-chime.mp3"]}),

    new Howl({
      src: ["https://s3-us-west-1.amazonaws.com/sayspring-prod/media/celtic-open-chime.mp3"] }),

    new Howl({
      src: ["https://s3-us-west-1.amazonaws.com/sayspring-prod/media/celtic-open-chime.mp3"] }),

    new Howl({
      src: ["https://s3-us-west-1.amazonaws.com/sayspring-prod/media/celtic-open-chime.mp3"] })],


    isLit: {
      1: false,
      2: false,
      3: false,
      4: false } },


  computed: {
    showScore: function showScore() {
      return "Score: " + this.score;
    } },


  methods: {
    startGame: function startGame() {
      this.playing = true;
      this.sequence = [];
      this.playerSequence = [];
      this.centerButton = "New Game";
      this.isWon = false;
      this.isWrong = false;
      this.score = 0;
      clearInterval(this.sequenceInterval);
      this.showSequence();
    },

    clicked: function clicked(tile) {
      if (this.isClickable) {
        this.playSound(tile);
        this.lightUp(tile);
        this.playerSequence.push(tile);
        this.checkWinLose();
      }
    },
    checkWinLose: function checkWinLose() {var _this = this;
      for (var i = 0; i < this.playerSequence.length; i++) {
        if (this.playerSequence[i] !== this.sequence[i]) {
          this.playerSequence = [];
          this.centerButton = "  Wrong! " ;
         this.isWrong = true
         swal({
          title: 'GAME OVER!',
          text: `:( !`,
          showCloseButton: true,
          confirmButtonText: 'New Game',
        })
         
          setTimeout(function () {
            _this.centerButton = "Reset";
            _this.isWrong = false;
          }, 1000);
          this.showSequence(true);
        
        }
      }

      if (this.playerSequence.length === this.sequence.length) {
        this.playerSequence = [];
        this.score++;
        if (this.score === 5) {
          this.centerButton = "Winner!";
          this.isClickable = false;
          this.isWon = true;
        } else {
          this.showSequence();
        }
      }
    },
    lightUp: function lightUp(tile) {var _this2 = this;
      this.isLit[tile] = true;
      setTimeout(function () {
        _this2.isLit[tile] = false;
      }, 300);
    },
    playSound: function playSound(tile) {
      this.sounds[tile - 1].play();
    },
    showSequence: function showSequence(redo) {var _this3 = this;
      var currentIndex = 0;
      var speed = this.sequence.length === 0 ? 900 : 1250;
      this.isClickable = false;
      if (!redo) {

        this.sequence.push(Math.floor(Math.random() * 4 + 1));
      }
      this.sequenceInterval = setInterval(function () {
        if (currentIndex >= _this3.sequence.length) {
          clearInterval(_this3.sequenceInterval);
          return _this3.isClickable = true;
        }
        _this3.playSound(_this3.sequence[currentIndex]);
        _this3.lightUp(_this3.sequence[currentIndex]);
        currentIndex++;
      }, speed);
    } } });